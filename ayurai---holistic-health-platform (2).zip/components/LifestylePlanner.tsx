
import React, { useState, useEffect } from 'react';
import { UserProfile, LifestylePlanItem, HealthVital } from '../types';
import { getLifestyleSuggestions } from '../services/geminiService';

interface Props {
  user: UserProfile;
  vitals: HealthVital[];
  onUpdatePlan: (plan: LifestylePlanItem[]) => void;
  savedPlan?: LifestylePlanItem[];
}

const LifestylePlanner: React.FC<Props> = ({ user, vitals, onUpdatePlan, savedPlan = [] }) => {
  const [suggestions, setSuggestions] = useState<LifestylePlanItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('All');

  useEffect(() => {
    const loadSuggestions = async () => {
      setLoading(true);
      try {
        const aiItems = await getLifestyleSuggestions(user, vitals);
        
        // Merge AI items with savedPlan state to maintain consistency
        const merged = aiItems.map((aiItem: any) => {
          const existing = savedPlan.find(s => s.title.toLowerCase() === aiItem.title.toLowerCase());
          return {
            ...aiItem,
            id: existing?.id || aiItem.id || `ai-${aiItem.title.toLowerCase().replace(/\s+/g, '-')}`,
            isPlanned: existing ? existing.isPlanned : false,
            completedAt: existing?.completedAt
          } as LifestylePlanItem;
        });
        
        setSuggestions(merged);
      } catch (err) {
        console.error("Ritual load error:", err);
      } finally {
        setLoading(false);
      }
    };
    loadSuggestions();
  }, [user.prakriti, vitals.length]);

  const handleTogglePlan = (item: LifestylePlanItem) => {
    const existingIndex = savedPlan.findIndex(s => s.title.toLowerCase() === item.title.toLowerCase());
    let updatedPlan: LifestylePlanItem[];

    if (existingIndex > -1) {
      const existingItem = savedPlan[existingIndex];
      if (existingItem.isPlanned) {
        // De-select but keep if it was completed (to preserve history)
        if (existingItem.completedAt) {
          updatedPlan = savedPlan.map((s, i) => i === existingIndex ? { ...s, isPlanned: false } : s);
        } else {
          updatedPlan = savedPlan.filter((_, i) => i !== existingIndex);
        }
      } else {
        // Re-select
        updatedPlan = savedPlan.map((s, i) => i === existingIndex ? { ...s, isPlanned: true } : s);
      }
    } else {
      // Add new
      updatedPlan = [...savedPlan, { ...item, isPlanned: true }];
    }

    onUpdatePlan(updatedPlan);
    setSuggestions(prev => prev.map(s => 
      s.title.toLowerCase() === item.title.toLowerCase() ? { ...s, isPlanned: !s.isPlanned } : s
    ));
  };

  const handleToggleComplete = (item: LifestylePlanItem) => {
    const isCompleted = !!item.completedAt;
    const newCompletedAt = isCompleted ? undefined : new Date().toISOString();

    const existingIndex = savedPlan.findIndex(s => s.title.toLowerCase() === item.title.toLowerCase());
    let updatedPlan: LifestylePlanItem[];

    if (existingIndex > -1) {
      updatedPlan = savedPlan.map((s, i) => i === existingIndex ? { ...s, completedAt: newCompletedAt } : s);
    } else {
      updatedPlan = [...savedPlan, { ...item, isPlanned: false, completedAt: newCompletedAt }];
    }

    onUpdatePlan(updatedPlan);
    setSuggestions(prev => prev.map(s => 
      s.title.toLowerCase() === item.title.toLowerCase() ? { ...s, completedAt: newCompletedAt } : s
    ));
  };

  const categories = ['All', 'Diet', 'Movement', 'Breath', 'Routine'];
  const times = ['Morning', 'Afternoon', 'Evening'];
  
  const filtered = suggestions.filter(s => filter === 'All' || s.category === filter);

  if (loading) {
    return (
      <div className="py-40 text-center animate-pulse">
        <div className="w-24 h-24 bg-teal-50 rounded-[40px] mx-auto mb-10 flex items-center justify-center text-5xl shadow-sm">🌱</div>
        <h3 className="text-3xl font-black text-slate-900 tracking-tight">Syncing Daily Rituals</h3>
        <p className="text-slate-400 font-bold mt-4 uppercase tracking-[0.2em] text-[10px]">Adjusting for {user.prakriti} Balance</p>
      </div>
    );
  }

  return (
    <div className="space-y-16">
      <div className="flex flex-col md:flex-row justify-between items-end gap-8">
        <div className="max-w-2xl">
          <h2 className="text-5xl font-black text-slate-900 tracking-tighter mb-4">Ayurvedic Ritual Planner</h2>
          <p className="text-lg text-slate-500 font-medium leading-relaxed">
            Personalized habits tailored to your <span className="text-teal-600 font-bold">{user.prakriti}</span> Prakriti 
            and current vitals. Add them to your tracker to build consistency.
          </p>
        </div>
        <div className="flex gap-2 bg-white p-2.5 rounded-[30px] shadow-sm border border-slate-100 overflow-x-auto max-w-full no-scrollbar">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`whitespace-nowrap px-8 py-4 rounded-2xl text-[11px] font-black uppercase tracking-widest transition-all ${filter === cat ? 'bg-teal-600 text-white shadow-2xl shadow-teal-100' : 'text-slate-400 hover:text-slate-600'}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-24">
        {times.map(time => {
          const timeItems = filtered.filter((f: any) => f.timeOfDay === time);
          if (timeItems.length === 0) return null;
          
          return (
            <div key={time} className="space-y-10">
              <div className="flex items-center gap-8">
                <span className="text-3xl font-black text-slate-900 flex items-center gap-4">
                  <span className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center text-2xl shadow-sm">
                    {time === 'Morning' ? '🌅' : time === 'Afternoon' ? '☀️' : '🌙'}
                  </span>
                  {time}
                </span>
                <div className="flex-1 h-px bg-slate-200/60"></div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                {timeItems.map(item => {
                  const isInPlan = savedPlan.some(s => s.title.toLowerCase() === item.title.toLowerCase() && s.isPlanned);
                  const isDone = !!item.completedAt;
                  
                  return (
                    <div 
                      key={item.id}
                      className={`group relative p-10 rounded-[50px] border-2 transition-all duration-500 ${isDone ? 'bg-teal-50/50 border-teal-200 opacity-80' : isInPlan ? 'bg-white border-teal-600 shadow-3xl shadow-teal-100/50 scale-[1.02]' : 'bg-white border-slate-100 hover:border-teal-200 shadow-sm'}`}
                    >
                      <div className="flex justify-between items-start mb-8">
                        <span className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-[0.15em] ${item.category === 'Diet' ? 'bg-orange-100 text-orange-700' : item.category === 'Movement' ? 'bg-blue-100 text-blue-700' : item.category === 'Breath' ? 'bg-teal-100 text-teal-700' : 'bg-purple-100 text-purple-700'}`}>
                          {item.category}
                        </span>
                        <button 
                          onClick={() => handleToggleComplete(item)}
                          className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all shadow-sm ${isDone ? 'bg-teal-600 text-white shadow-teal-200' : 'bg-slate-50 text-slate-300 hover:bg-teal-500 hover:text-white'}`}
                        >
                          <span className="text-xl font-black">{isDone ? '✓' : '○'}</span>
                        </button>
                      </div>

                      <h4 className={`text-2xl font-black mb-4 leading-tight transition-colors ${isDone ? 'text-teal-900 line-through' : 'text-slate-900 group-hover:text-teal-700'}`}>{item.title}</h4>
                      <p className="text-slate-500 text-sm font-medium leading-relaxed mb-10">{item.description}</p>
                      
                      <div className="bg-slate-50/80 p-6 rounded-[35px] border border-slate-100 mb-10">
                        <p className="text-[10px] font-black text-teal-600 uppercase tracking-widest mb-3">Therapeutic Benefit</p>
                        <p className="text-xs font-bold text-slate-600 leading-relaxed italic">"{item.benefits}"</p>
                      </div>

                      <button
                        onClick={() => handleTogglePlan(item)}
                        className={`w-full py-5 rounded-[28px] font-black text-[11px] uppercase tracking-widest transition-all ${isInPlan ? 'bg-slate-100 text-red-500 hover:bg-red-50' : 'bg-teal-900 text-white hover:bg-teal-800 shadow-2xl shadow-teal-900/20'}`}
                      >
                        {isInPlan ? 'Remove Ritual' : 'Add to Tracker'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default LifestylePlanner;
