
import React, { useRef, useState, useEffect } from 'react';
import { analyzeSkinTexture } from '../services/geminiService';
import { SkinAnalysisResult } from '../types';

interface Props {
  userPrakriti: string;
  onAnalysisComplete: (result: SkinAnalysisResult) => void;
}

const SkinCapture: React.FC<Props> = ({ userPrakriti, onAnalysisComplete }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [preview, setPreview] = useState<string | null>(null);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'user',
          width: { ideal: 1024 },
          height: { ideal: 768 }
        },
        audio: false 
      });
      setStream(mediaStream);
      if (videoRef.current) videoRef.current.srcObject = mediaStream;
      setError(null);
      setPreview(null);
    } catch (err: any) {
      console.error("Camera Access Error:", err);
      if (err.name === 'NotAllowedError') {
        setError("Camera is blocked. Please allow camera access in your browser settings.");
      } else {
        setError("Could not start camera. Please upload a photo instead.");
      }
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const processImage = (imgSource: HTMLImageElement | HTMLVideoElement) => {
    if (!canvasRef.current) return null;
    const context = canvasRef.current.getContext('2d');
    if (!context) return null;

    const MAX_DIM = 640;
    let width = imgSource instanceof HTMLVideoElement ? imgSource.videoWidth : imgSource.width;
    let height = imgSource instanceof HTMLVideoElement ? imgSource.videoHeight : imgSource.height;

    if (width > height) {
      if (width > MAX_DIM) {
        height *= MAX_DIM / width;
        width = MAX_DIM;
      }
    } else {
      if (height > MAX_DIM) {
        width *= MAX_DIM / height;
        height = MAX_DIM;
      }
    }

    canvasRef.current.width = width;
    canvasRef.current.height = height;
    context.drawImage(imgSource, 0, 0, width, height);
    return canvasRef.current.toDataURL('image/jpeg', 0.65);
  };

  const handleCapture = () => {
    if (!videoRef.current) return;
    const dataUrl = processImage(videoRef.current);
    if (dataUrl) {
      setPreview(dataUrl);
      stopCamera();
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const dataUrl = processImage(img);
        if (dataUrl) setPreview(dataUrl);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
    stopCamera();
  };

  const startAnalysis = async () => {
    if (!preview) return;
    setAnalyzing(true);
    setError(null);
    try {
      const result = await analyzeSkinTexture(preview, userPrakriti);
      onAnalysisComplete(result);
    } catch (err: any) {
      console.error("Analysis Failure:", err);
      setError("We couldn't analyze the photo. Please make sure the lighting is good and try again.");
    } finally {
      setAnalyzing(false);
    }
  };

  useEffect(() => {
    return () => stopCamera();
  }, []);

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-[40px] p-8 md:p-12 shadow-2xl border border-slate-100">
      <div className="text-center mb-10">
        <h3 className="text-3xl font-black text-slate-900 mb-3 tracking-tight">Let's Look at Your Skin</h3>
        <p className="text-slate-500 max-w-sm mx-auto text-sm leading-relaxed">
          Your skin can tell us a lot about your internal health. Take a clear photo of your skin in a bright room.
        </p>
      </div>

      <div className="space-y-8">
        {!preview && !stream && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button 
              onClick={startCamera}
              className="bg-teal-600 text-white p-10 rounded-[32px] font-black text-sm uppercase tracking-widest hover:bg-teal-700 transition flex flex-col items-center gap-4 group"
            >
              <span className="text-4xl group-hover:scale-110 transition">📸</span>
              Take Photo
            </button>
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="bg-slate-50 border-2 border-dashed border-slate-200 p-10 rounded-[32px] font-black text-sm uppercase tracking-widest text-slate-400 hover:border-teal-400 hover:text-teal-600 transition flex flex-col items-center gap-4 group"
            >
              <span className="text-4xl group-hover:scale-110 transition">📁</span>
              Upload a Photo
            </button>
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileUpload} />
          </div>
        )}

        {stream && !preview && (
          <div className="relative aspect-video bg-black rounded-[40px] overflow-hidden border-4 border-white shadow-2xl">
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
            <div className="absolute inset-0 border-[40px] border-white/5 pointer-events-none rounded-[40px]"></div>
            <div className="absolute bottom-8 left-0 w-full px-10 flex justify-between items-center">
              <button onClick={stopCamera} className="w-12 h-12 bg-white/20 backdrop-blur-xl text-white rounded-full font-black flex items-center justify-center">✕</button>
              <button 
                onClick={handleCapture}
                className="bg-white text-slate-900 px-8 py-4 rounded-full font-black uppercase text-xs tracking-widest shadow-xl hover:scale-105 transition"
              >
                Snap Photo
              </button>
            </div>
          </div>
        )}

        {preview && (
          <div className="space-y-6">
            <div className="relative aspect-video rounded-[40px] overflow-hidden border-4 border-white shadow-2xl">
              <img src={preview} className="w-full h-full object-cover" alt="Skin Preview" />
              {analyzing && (
                <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-md flex flex-col items-center justify-center text-white p-10 text-center">
                  <div className="w-12 h-12 border-4 border-teal-400 border-t-transparent rounded-full animate-spin mb-6"></div>
                  <h4 className="font-black text-xl mb-2">Analyzing...</h4>
                  <p className="text-xs text-teal-400 font-bold uppercase tracking-widest">Checking your body balance</p>
                </div>
              )}
            </div>
            
            {!analyzing && (
              <div className="flex gap-4">
                <button 
                  onClick={() => { setPreview(null); startCamera(); }}
                  className="flex-1 py-4 bg-slate-100 text-slate-500 rounded-2xl font-black uppercase text-xs tracking-widest"
                >
                  Retake
                </button>
                <button 
                  onClick={startAnalysis}
                  className="flex-2 py-4 bg-teal-600 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-teal-100"
                >
                  Analyze Photo →
                </button>
              </div>
            )}
          </div>
        )}

        {error && (
          <div className="p-6 bg-red-50 border border-red-100 rounded-3xl">
            <p className="text-red-600 text-xs font-bold leading-relaxed">{error}</p>
          </div>
        )}
      </div>

      <canvas ref={canvasRef} className="hidden" />
      
      <div className="mt-12 pt-8 border-t border-slate-100 flex items-center justify-center gap-4 text-[10px] font-black text-slate-300 uppercase tracking-widest">
        <span>Simple AI Analysis</span>
        <span className="w-1.5 h-1.5 bg-slate-100 rounded-full"></span>
        <span>Secure & Private</span>
      </div>
    </div>
  );
};

export default SkinCapture;
