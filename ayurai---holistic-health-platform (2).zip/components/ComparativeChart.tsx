
import React from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Legend } from 'recharts';
import { PrakritiScore } from '../types';

interface Props {
  baseline: PrakritiScore;
  current: PrakritiScore;
}

const ComparativeChart: React.FC<Props> = ({ baseline, current }) => {
  const data = [
    { subject: 'Vata', baseline: baseline.Vata, current: current.Vata, fullMark: 17 },
    { subject: 'Pitta', baseline: baseline.Pitta, current: current.Pitta, fullMark: 17 },
    { subject: 'Kapha', baseline: baseline.Kapha, current: current.Kapha, fullMark: 17 },
  ];

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="70%" data={data}>
          <PolarGrid stroke="#e2e8f0" />
          <PolarAngleAxis dataKey="subject" tick={{ fontSize: 12, fontWeight: 700, fill: '#64748b' }} />
          <PolarRadiusAxis angle={30} domain={[0, 10]} hide />
          <Radar
            name="Lifelong Baseline"
            dataKey="baseline"
            stroke="#0f766e"
            fill="#0f766e"
            fillOpacity={0.2}
          />
          <Radar
            name="Current State"
            dataKey="current"
            stroke="#10b981"
            fill="#10b981"
            fillOpacity={0.4}
          />
          <Legend wrapperStyle={{ paddingTop: '20px', fontSize: '10px', fontWeight: 'bold', textTransform: 'uppercase' }} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ComparativeChart;
