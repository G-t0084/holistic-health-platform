
import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { LifestylePlanItem } from '../types';

interface Props {
  plan: LifestylePlanItem[];
}

const ActivityGraph: React.FC<Props> = ({ plan }) => {
  const data = useMemo(() => {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    
    // Initialize array for all days of the month
    const monthlyData = Array.from({ length: daysInMonth }, (_, i) => ({
      day: i + 1,
      count: 0,
      isToday: (i + 1) === now.getDate()
    }));

    // Fill with actual data
    plan.forEach(item => {
      if (item.completedAt) {
        const date = new Date(item.completedAt);
        if (date.getFullYear() === year && date.getMonth() === month) {
          const dayIndex = date.getDate() - 1;
          if (monthlyData[dayIndex]) {
            monthlyData[dayIndex].count++;
          }
        }
      }
    });

    return monthlyData;
  }, [plan]);

  const stats = useMemo(() => {
    const total = data.reduce((sum, d) => sum + d.count, 0);
    const avg = (total / new Date().getDate()).toFixed(1);
    return { total, avg };
  }, [data]);

  const exportCSV = () => {
    const headers = "Date,Tasks Completed\n";
    const rows = data.map(d => `${new Date().getMonth() + 1}/${d.day},${d.count}`).join("\n");
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AyurAI_Activity_${new Date().getMonth() + 1}_${new Date().getFullYear()}.csv`;
    a.click();
  };

  return (
    <div className="bg-white p-8 rounded-[40px] shadow-sm border border-slate-200">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h3 className="text-xl font-black text-slate-900">Ritual Consistency</h3>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-1">Monthly Completion Tracking</p>
        </div>
        <div className="flex gap-4">
          <div className="text-right">
            <div className="text-2xl font-black text-teal-600">{stats.total}</div>
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Total Done</div>
          </div>
          <div className="w-px h-8 bg-slate-100 self-center"></div>
          <div className="text-right">
            <div className="text-2xl font-black text-lime-500">{stats.avg}</div>
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Daily Avg</div>
          </div>
          <button 
            onClick={exportCSV}
            className="ml-4 p-3 bg-slate-50 text-slate-400 hover:text-teal-600 rounded-2xl transition-colors border border-slate-100"
            title="Export Data"
          >
            📥
          </button>
        </div>
      </div>

      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 0, right: 0, left: -25, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis 
              dataKey="day" 
              axisLine={false} 
              tickLine={false} 
              tick={{ fontSize: 10, fontWeight: 700, fill: '#94a3b8' }}
              interval={2}
            />
            <YAxis 
              axisLine={false} 
              tickLine={false} 
              tick={{ fontSize: 10, fontWeight: 700, fill: '#94a3b8' }}
              allowDecimals={false}
            />
            <Tooltip
              cursor={{ fill: '#f8fafc' }}
              contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontSize: '10px', fontWeight: 'bold' }}
              labelFormatter={(day) => `Day ${day} of Month`}
            />
            <Bar dataKey="count" radius={[4, 4, 0, 0]}>
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={entry.isToday ? '#10b981' : '#0f766e'} 
                  fillOpacity={entry.isToday ? 1 : 0.6}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      
      <div className="mt-6 flex items-center justify-center gap-6 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-teal-700 opacity-60"></div>
          <span>Past Days</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
          <span>Today</span>
        </div>
      </div>
    </div>
  );
};

export default ActivityGraph;
