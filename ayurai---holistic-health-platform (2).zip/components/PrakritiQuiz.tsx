
import React, { useState } from 'react';
import { PRAKRITI_QUESTIONS } from '../constants';
import { Dosha, PrakritiScore, UserProfile, AssessmentRecord } from '../types';

interface Props {
  onComplete: (
    baseline: { scores: PrakritiScore; dominant: Dosha; answers: Record<string, Dosha> },
    current: { scores: PrakritiScore; dominant: Dosha; answers: Record<string, Dosha> },
    bioData: Partial<UserProfile>
  ) => void;
}

const PrakritiQuiz: React.FC<Props> = ({ onComplete }) => {
  const [phase, setPhase] = useState<'bio' | 'quiz'>('bio');
  const [currentStep, setCurrentStep] = useState(0);
  const [bioData, setBioData] = useState({
    name: '',
    dob: '',
    birthPlace: '',
    currentLocation: ''
  });
  
  const [baselineAnswers, setBaselineAnswers] = useState<Record<string, Dosha>>({});
  const [currentAnswers, setCurrentAnswers] = useState<Record<string, Dosha>>({});

  const handleBioSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (bioData.name && bioData.dob && bioData.birthPlace && bioData.currentLocation) {
      setPhase('quiz');
    }
  };

  const selectBaseline = (dosha: Dosha) => {
    setBaselineAnswers(prev => ({ ...prev, [PRAKRITI_QUESTIONS[currentStep].id]: dosha }));
    // Auto-fill current if not yet selected to speed up UX
    if (!currentAnswers[PRAKRITI_QUESTIONS[currentStep].id]) {
      setCurrentAnswers(prev => ({ ...prev, [PRAKRITI_QUESTIONS[currentStep].id]: dosha }));
    }
  };

  const selectCurrent = (dosha: Dosha) => {
    setCurrentAnswers(prev => ({ ...prev, [PRAKRITI_QUESTIONS[currentStep].id]: dosha }));
  };

  const handleNext = () => {
    if (currentStep < PRAKRITI_QUESTIONS.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      // Calculate Baseline
      const bScores: PrakritiScore = { [Dosha.VATA]: 0, [Dosha.PITTA]: 0, [Dosha.KAPHA]: 0 };
      // Fix: Cast values to Dosha[] and use 'keyof' to resolve index type errors for PrakritiScore
      (Object.values(baselineAnswers) as Dosha[]).forEach(d => { 
        if (d in bScores) bScores[d as keyof PrakritiScore]++; 
      });
      let bDominant = Dosha.VATA;
      if (bScores[Dosha.PITTA] > bScores[bDominant]) bDominant = Dosha.PITTA;
      if (bScores[Dosha.KAPHA] > bScores[bDominant]) bDominant = Dosha.KAPHA;

      // Calculate Current
      const cScores: PrakritiScore = { [Dosha.VATA]: 0, [Dosha.PITTA]: 0, [Dosha.KAPHA]: 0 };
      // Fix: Cast values to Dosha[] and use 'keyof' to resolve index type errors for PrakritiScore
      (Object.values(currentAnswers) as Dosha[]).forEach(d => { 
        if (d in cScores) cScores[d as keyof PrakritiScore]++; 
      });
      let cDominant = Dosha.VATA;
      if (cScores[Dosha.PITTA] > cScores[cDominant]) cDominant = Dosha.PITTA;
      if (cScores[Dosha.KAPHA] > cScores[cDominant]) cDominant = Dosha.KAPHA;

      onComplete(
        { scores: bScores, dominant: bDominant, answers: baselineAnswers },
        { scores: cScores, dominant: cDominant, answers: currentAnswers },
        bioData
      );
    }
  };

  const categoryMap: Record<string, string> = {
    'Structural': 'Body Frame & Traits',
    'Metabolic': 'Digestion & Vitality',
    'Mental': 'Psychology & Patterns'
  };

  if (phase === 'bio') {
    return (
      <div className="max-w-xl mx-auto p-8 bg-white rounded-[40px] shadow-2xl border border-teal-50">
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-teal-600 rounded-3xl flex items-center justify-center text-white text-3xl font-black mx-auto mb-6">1</div>
          <h2 className="text-3xl font-black text-slate-900 mb-2">Basic Information</h2>
          <p className="text-slate-500 text-sm">We need this to calibrate your age and environment factors.</p>
        </div>
        <form onSubmit={handleBioSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-4">Full Name</label>
            <input required type="text" placeholder="Your Name" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-teal-500 transition" value={bioData.name} onChange={e => setBioData({...bioData, name: e.target.value})} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-4">Birth Date</label>
              <input required type="date" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-teal-500 transition" value={bioData.dob} onChange={e => setBioData({...bioData, dob: e.target.value})} />
            </div>
            <div className="space-y-2">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-4">Birth Place</label>
              <input required type="text" placeholder="City" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-teal-500 transition" value={bioData.birthPlace} onChange={e => setBioData({...bioData, birthPlace: e.target.value})} />
            </div>
          </div>
          <div className="space-y-2">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-4">Current Location</label>
            <input required type="text" placeholder="Current City" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-teal-500 transition" value={bioData.currentLocation} onChange={e => setBioData({...bioData, currentLocation: e.target.value})} />
          </div>
          <button type="submit" className="w-full py-5 bg-teal-600 text-white font-black rounded-3xl hover:bg-teal-700 transition shadow-xl shadow-teal-100 uppercase tracking-widest text-xs">Start Dual Analysis</button>
        </form>
      </div>
    );
  }

  const currentQuestion = PRAKRITI_QUESTIONS[currentStep];
  const progress = ((currentStep + 1) / PRAKRITI_QUESTIONS.length) * 100;
  const isQuestionAnswered = baselineAnswers[currentQuestion.id] && currentAnswers[currentQuestion.id];

  return (
    <div className="max-w-3xl mx-auto p-10 bg-white rounded-[40px] shadow-2xl border border-teal-50">
      <div className="mb-10 text-center">
        <span className="inline-block py-1 px-4 bg-teal-50 text-teal-700 rounded-full text-[10px] font-black uppercase tracking-widest mb-4">
          {categoryMap[currentQuestion.category]} • Question {currentStep + 1} of {PRAKRITI_QUESTIONS.length}
        </span>
        <h2 className="text-2xl font-black text-slate-900 leading-tight">{currentQuestion.question}</h2>
        <div className="mt-6 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden max-w-xs mx-auto">
          <div className="bg-teal-600 h-full transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        {/* Baseline Column */}
        <div className="space-y-6">
          <div className="text-center">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4">A. Lifelong Baseline</h4>
            <p className="text-[10px] text-slate-400 italic">How have you been most of your life?</p>
          </div>
          <div className="space-y-3">
            {currentQuestion.options.map((option, idx) => (
              <button 
                key={idx} 
                onClick={() => selectBaseline(option.dosha)} 
                className={`w-full p-5 text-left border-2 rounded-2xl transition-all flex items-center gap-4 group ${baselineAnswers[currentQuestion.id] === option.dosha ? 'bg-teal-900 border-teal-900 text-white shadow-lg' : 'bg-white border-slate-100 hover:border-teal-200 text-slate-700'}`}
              >
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 ${baselineAnswers[currentQuestion.id] === option.dosha ? 'bg-white border-white text-teal-900' : 'border-slate-200'}`}>
                   {baselineAnswers[currentQuestion.id] === option.dosha && <span className="text-[10px] font-black">B</span>}
                </div>
                <span className="text-xs font-bold leading-tight">{option.text}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Current Column */}
        <div className="space-y-6">
          <div className="text-center">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4">B. Current State</h4>
            <p className="text-[10px] text-slate-400 italic">How do you feel lately (last 30 days)?</p>
          </div>
          <div className="space-y-3">
            {currentQuestion.options.map((option, idx) => (
              <button 
                key={idx} 
                onClick={() => selectCurrent(option.dosha)} 
                className={`w-full p-5 text-left border-2 rounded-2xl transition-all flex items-center gap-4 group ${currentAnswers[currentQuestion.id] === option.dosha ? 'bg-emerald-600 border-emerald-600 text-white shadow-lg' : 'bg-white border-slate-100 hover:border-emerald-200 text-slate-700'}`}
              >
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 ${currentAnswers[currentQuestion.id] === option.dosha ? 'bg-white border-white text-emerald-600' : 'border-slate-200'}`}>
                   {currentAnswers[currentQuestion.id] === option.dosha && <span className="text-[10px] font-black">C</span>}
                </div>
                <span className="text-xs font-bold leading-tight">{option.text}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-12 flex justify-center">
        <button 
          onClick={handleNext}
          disabled={!isQuestionAnswered}
          className={`px-12 py-5 rounded-3xl font-black uppercase tracking-widest text-xs transition-all ${isQuestionAnswered ? 'bg-teal-900 text-white shadow-xl hover:scale-105' : 'bg-slate-100 text-slate-300 cursor-not-allowed'}`}
        >
          {currentStep === PRAKRITI_QUESTIONS.length - 1 ? 'Finish Assessment' : 'Next Question'}
        </button>
      </div>

      <div className="mt-8 text-center">
         <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest">Comparison is key to identifying "Vikriti" (Imbalance)</p>
      </div>
    </div>
  );
};

export default PrakritiQuiz;
