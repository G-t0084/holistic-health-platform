
import React, { useState, useRef, useEffect } from 'react';
import { UserProfile, HealthVital, Message } from '../types';
import { getHolisticAdvice } from '../services/geminiService';
import { marked } from 'marked';

interface Props {
  user: UserProfile;
  vitals: HealthVital[];
}

const AyurChat: React.FC<Props> = ({ user, vitals }) => {
  const [messages, setMessages] = useState<Message[]>([
    { 
      role: 'model', 
      text: `Hello ${user.name}, I am your AyurAI Friend. How can I help you find balance today? I see your latest BP is ${vitals.find(v => v.type === 'BP')?.value || 'not logged'} and you have a ${user.prakriti} nature.`,
      timestamp: new Date().toISOString()
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMsg: Message = { role: 'user', text: input, timestamp: new Date().toISOString() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const history = messages.map(m => ({ role: m.role, text: m.text }));
      const response = await getHolisticAdvice(user, vitals, history, input);
      const aiMsg: Message = { role: 'model', text: response, timestamp: new Date().toISOString() };
      setMessages(prev => [...prev, aiMsg]);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-[40px] shadow-sm border border-slate-200 flex flex-col h-[600px] overflow-hidden">
      <div className="p-6 border-b border-slate-100 bg-teal-50 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-teal-600 rounded-2xl flex items-center justify-center text-white text-xl">🧘</div>
          <div>
            <h3 className="font-black text-slate-900 leading-tight">AyurAI Chat</h3>
            <p className="text-[10px] font-black text-teal-600 uppercase tracking-widest">Personalized Wisdom</p>
          </div>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] p-5 rounded-[30px] shadow-sm ${m.role === 'user' ? 'bg-teal-600 text-white rounded-tr-none' : 'bg-slate-50 text-slate-800 rounded-tl-none border border-slate-100'}`}>
              <div className="prose prose-sm max-w-none text-inherit leading-relaxed" dangerouslySetInnerHTML={{ __html: marked.parse(m.text) }} />
              <p className={`text-[8px] font-bold mt-2 uppercase tracking-widest ${m.role === 'user' ? 'text-teal-200' : 'text-slate-400'}`}>
                {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-slate-50 p-6 rounded-[30px] rounded-tl-none border border-slate-100 flex gap-2">
              <div className="w-2 h-2 bg-teal-600 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-teal-600 rounded-full animate-bounce delay-100"></div>
              <div className="w-2 h-2 bg-teal-600 rounded-full animate-bounce delay-200"></div>
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSend} className="p-6 bg-slate-50/50 border-t border-slate-100 flex gap-4">
        <input 
          type="text" 
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Ask about diet, herbs, or your vitals..."
          className="flex-1 bg-white px-6 py-4 rounded-3xl text-sm border border-slate-200 outline-none focus:border-teal-500 transition shadow-sm"
        />
        <button 
          disabled={loading || !input.trim()}
          className="bg-teal-600 text-white w-14 h-14 rounded-3xl flex items-center justify-center hover:bg-teal-700 transition shadow-lg shadow-teal-100 active:scale-95 disabled:opacity-50"
        >
          <span className="text-xl">➔</span>
        </button>
      </form>
    </div>
  );
};

export default AyurChat;
