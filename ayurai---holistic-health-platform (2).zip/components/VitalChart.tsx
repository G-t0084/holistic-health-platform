
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { HealthVital } from '../types';

interface Props {
  data: HealthVital[];
  type: 'BP' | 'Sugar' | 'Weight' | 'Height';
}

const VitalChart: React.FC<Props> = ({ data, type }) => {
  const chartData = data
    .filter(v => v.type === type)
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    .map(v => ({
      time: new Date(v.timestamp).toLocaleDateString(),
      val1: v.value,
      val2: v.secondary,
      fullDate: new Date(v.timestamp).toLocaleString()
    }));

  if (chartData.length === 0) {
    return (
      <div className="h-40 flex items-center justify-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 mt-4">
        <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">No {type} records yet</p>
      </div>
    );
  }

  const getLabel = () => {
    switch (type) {
      case 'BP': return 'Pressure (mmHg)';
      case 'Sugar': return 'Sugar (mg/dL)';
      case 'Weight': return 'Weight (kg)';
      case 'Height': return 'Height (cm)';
      default: return 'Value';
    }
  };

  const getStrokeColor = () => {
    switch (type) {
      case 'BP': return '#0F766E';
      case 'Sugar': return '#F59E0B';
      case 'Weight': return '#6366f1';
      case 'Height': return '#ec4899';
      default: return '#0F766E';
    }
  };

  return (
    <div className="mt-6">
      <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-3">{type} Trends</h4>
      <div className="h-48 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
            <XAxis dataKey="time" hide />
            <YAxis domain={['auto', 'auto']} tick={{fontSize: 10}} />
            <Tooltip 
              labelFormatter={(v, items) => items[0]?.payload.fullDate}
              contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)', fontSize: '10px' }}
            />
            {type === 'BP' ? (
              <>
                <Line type="monotone" dataKey="val1" name="Systolic" stroke="#0F766E" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                <Line type="monotone" dataKey="val2" name="Diastolic" stroke="#14B8A6" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                <ReferenceLine y={140} stroke="#f87171" strokeDasharray="3 3" />
              </>
            ) : (
              <Line type="monotone" dataKey="val1" name={getLabel()} stroke={getStrokeColor()} strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
            )}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default VitalChart;
