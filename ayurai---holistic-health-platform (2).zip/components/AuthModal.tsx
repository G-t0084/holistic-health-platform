
import React, { useState } from 'react';
import { authService, UserAccount } from '../services/authService';

interface Props {
  onSuccess: (account: UserAccount) => void;
  onClose: () => void;
}

type AuthMode = 'signin' | 'signup' | 'forgot' | 'otp';

const AuthModal: React.FC<Props> = ({ onSuccess, onClose }) => {
  const [mode, setMode] = useState<AuthMode>('signin');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  // Form Fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [otp, setOtp] = useState('');

  const validatePassword = () => {
    if (password.length < 8) return "Password must be at least 8 characters.";
    if (!/[A-Z]/.test(password)) return "Include at least one capital letter.";
    if (!/[0-9]/.test(password)) return "Include at least one number.";
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (mode === 'signup') {
        if (!name.trim()) throw new Error("Name is required.");
        const pwdError = validatePassword();
        if (pwdError) throw new Error(pwdError);
        if (password !== confirmPassword) throw new Error("Passwords do not match.");
        
        const account = await authService.register(name, email, password);
        onSuccess(account);
      } else if (mode === 'signin') {
        const account = await authService.loginWithPassword(email, password);
        onSuccess(account);
      } else if (mode === 'otp') {
        const account = await authService.loginWithEmail(email, otp);
        onSuccess(account);
      } else if (mode === 'forgot') {
        await authService.sendOTP(email);
        alert("A password reset link has been sent to your email (Demo).");
        setMode('signin');
      }
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-white rounded-[40px] p-8 md:p-12 w-full max-w-md shadow-2xl border border-slate-100 relative overflow-hidden animate-in zoom-in-95 duration-200">
        <button onClick={onClose} className="absolute top-6 right-6 text-slate-400 hover:text-slate-600 transition p-2 bg-slate-50 rounded-full" aria-label="Close">✕</button>
        
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-teal-600 rounded-[22px] flex items-center justify-center text-white font-bold text-3xl mx-auto mb-6 shadow-xl shadow-teal-100">A</div>
          <h3 className="text-3xl font-black text-slate-900 mb-2">
            {mode === 'signup' ? 'Create Account' : mode === 'forgot' ? 'Reset Password' : 'Welcome Back'}
          </h3>
          <p className="text-slate-500 text-sm">
            {mode === 'signup' ? 'Join AyurAI for holistic health guidance.' : 'Continue your journey with us.'}
          </p>
        </div>

        {/* Tab Switcher */}
        {mode !== 'forgot' && mode !== 'otp' && (
          <div className="flex bg-slate-100 p-1.5 rounded-2xl mb-8 border border-slate-200">
            <button 
              onClick={() => setMode('signin')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${mode === 'signin' ? 'bg-white text-teal-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Sign In
            </button>
            <button 
              onClick={() => setMode('signup')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${mode === 'signup' ? 'bg-white text-teal-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Sign Up
            </button>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'signup' && (
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Full Name</label>
              <input 
                type="text" required placeholder="John Doe"
                className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-teal-500 focus:bg-white transition text-sm"
                value={name} onChange={e => setName(e.target.value)}
              />
            </div>
          )}

          <div className="space-y-1">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Email Address</label>
            <input 
              type="email" required placeholder="name@example.com"
              className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-teal-500 focus:bg-white transition text-sm"
              value={email} onChange={e => setEmail(e.target.value)}
            />
          </div>

          {(mode === 'signin' || mode === 'signup') && (
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Password</label>
              <input 
                type="password" required placeholder="••••••••"
                className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-teal-500 focus:bg-white transition text-sm"
                value={password} onChange={e => setPassword(e.target.value)}
              />
            </div>
          )}

          {mode === 'signup' && (
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Confirm Password</label>
              <input 
                type="password" required placeholder="••••••••"
                className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-teal-500 focus:bg-white transition text-sm"
                value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)}
              />
            </div>
          )}

          {mode === 'signin' && (
            <div className="flex justify-end">
              <button type="button" onClick={() => setMode('forgot')} className="text-[10px] font-black text-teal-600 uppercase tracking-widest hover:underline">Forgot Password?</button>
            </div>
          )}

          <button 
            type="submit" disabled={loading}
            className="w-full py-4 bg-teal-600 text-white rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-teal-700 transition shadow-xl shadow-teal-100 disabled:opacity-50 active:scale-[0.98]"
          >
            {loading ? 'Processing...' : mode === 'signup' ? 'Create Account' : mode === 'forgot' ? 'Send Reset Link' : 'Sign In'}
          </button>
        </form>

        {(mode === 'signin' || mode === 'signup') && (
          <div className="mt-8 space-y-6">
            <div className="flex items-center gap-4">
              <div className="flex-1 h-px bg-slate-100"></div>
              <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">or</span>
              <div className="flex-1 h-px bg-slate-100"></div>
            </div>

            <div className="text-center">
              <button 
                type="button" 
                onClick={() => { setMode('otp'); setError(''); }}
                className="text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-teal-600 transition"
              >
                Sign in with OTP / Magic Link
              </button>
            </div>
          </div>
        )}

        {mode === 'forgot' && (
          <div className="mt-6 text-center">
            <button onClick={() => setMode('signin')} className="text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-teal-600 transition">Back to Login</button>
          </div>
        )}

        {error && <div className="mt-6 text-center text-[10px] text-red-500 font-bold p-3 bg-red-50 rounded-xl animate-in fade-in slide-in-from-top-1">{error}</div>}
      </div>
    </div>
  );
};

export default AuthModal;
