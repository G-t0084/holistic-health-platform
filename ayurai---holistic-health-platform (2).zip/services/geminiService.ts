
import { GoogleGenAI, Type } from "@google/genai";
import { UserProfile, HealthVital, GuidanceMode, SkinAnalysisResult, AssessmentRecord } from "../types";

export const getPrakritiReport = async (userProfile: UserProfile) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-flash-preview";
  const prompt = `
    Create a friendly, easy-to-read HEALTH SUMMARY for ${userProfile.name}.
    They are a ${userProfile.prakriti} body type.
    
    INSTRUCTIONS:
    - Use simple English. 
    - Use **BOLD** headings.
    - Focus on empowerment.

    Structure:
    # YOUR PERSONAL HEALTH MAP
    **## 1. WHO YOU ARE (Natural Body Type)**
    **## 2. HOW YOUR BODY WORKS (Digestion & Energy)**
    **## 3. STEPS TO STAY HEALTHY**
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: { temperature: 0.5 }
    });
    return response.text || "I couldn't create your report right now.";
  } catch (error) { return "Something went wrong."; }
};

export const getComparativeAnalysis = async (userProfile: UserProfile, baseline: AssessmentRecord, current: AssessmentRecord) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-pro-preview";
  const prompt = `
    Analyze the shift in health for ${userProfile.name}.
    
    BASELINE (Prakriti): Vata:${baseline.scores.Vata}, Pitta:${baseline.scores.Pitta}, Kapha:${baseline.scores.Kapha}
    CURRENT STATE (Vikriti): Vata:${current.scores.Vata}, Pitta:${current.scores.Pitta}, Kapha:${current.scores.Kapha}
    
    User DOB: ${userProfile.dob}.
    
    INSTRUCTIONS:
    - Identify which Dosha is "Aggravated" (increased significantly from baseline).
    - Provide 3 immediate "re-balancing" steps.
    - Format as Markdown with **BOLD** headers.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: { 
        temperature: 0.6,
        thinkingConfig: { thinkingBudget: 2000 }
      }
    });
    return response.text || "Analysis unavailable.";
  } catch (error) { return "Error during comparison."; }
};

export const analyzeSkinTexture = async (base64Image: string, userPrakriti: string): Promise<SkinAnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-flash-preview";
  const base64Data = base64Image.includes(',') ? base64Image.split(',')[1].replace(/\s/g, '') : base64Image.replace(/\s/g, '');
  const imagePart = { inlineData: { data: base64Data, mimeType: "image/jpeg" } };

  const prompt = `Look at this skin photo. User has ${userPrakriti} type. Return JSON: { "texture": string, "moisture": string, "prakritiMarkers": string[], "suggestions": string[] }`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: { parts: [imagePart, { text: prompt }] },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            texture: { type: Type.STRING },
            moisture: { type: Type.STRING },
            prakritiMarkers: { type: Type.ARRAY, items: { type: Type.STRING } },
            suggestions: { type: Type.ARRAY, items: { type: Type.STRING } }
          }
        }
      }
    });
    return { ...JSON.parse(response.text?.trim() || "{}"), imageUrl: base64Image };
  } catch (error) { throw new Error("Analysis failed."); }
};

export const getHolisticAdvice = async (userProfile: UserProfile, vitals: HealthVital[], chatHistory: {role: string, text: string}[], userPrompt: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-pro-preview";
  const latestVitals = vitals.slice(-5).map(v => `${v.type}: ${v.value}${v.secondary ? '/' + v.secondary : ''}`).join(', ');
  
  const systemInstruction = `
    You are AyurAI Friend, a wise and empathetic Ayurvedic assistant. 
    User: ${userProfile.name}. Type: ${userProfile.prakriti}. 
    Latest Vitals: ${latestVitals}.
    
    Goal: Provide advice that balances their current state. 
    - If BP is high, suggest cooling/calming activities.
    - If weight is high, suggest Kapha-reducing (stimulating) activities.
    - Always stay humble: "I am an AI assistant, consult a Vaidya for medical prescriptions."
    - Use Markdown.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: [...chatHistory.map(c => ({ role: c.role === 'user' ? 'user' : 'model', parts: [{ text: c.text }] })), { role: 'user', parts: [{ text: userPrompt }] }],
      config: { systemInstruction, temperature: 0.7, thinkingConfig: { thinkingBudget: 1500 } }
    });
    return response.text || "I'm reflecting on your health. Could you repeat that?";
  } catch (error) { return "The universe is quiet for a moment. Please try again later."; }
};

export const getLifestyleSuggestions = async (userProfile: UserProfile, vitals: HealthVital[]) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-pro-preview";
  const latestVitals = vitals.slice(-5).map(v => `${v.type}: ${v.value}`).join(', ');
  
  const prompt = `
    Generate a highly personalized daily routine for ${userProfile.name} (${userProfile.prakriti}).
    Recent Vitals: ${latestVitals}.
    
    Address any issues:
    - If BP > 130/80: Focus on "Breath" and calming rituals.
    - If weight indicates imbalance: Suggest "Movement".
    - Align with their Dosha imbalance (Vikriti).
    
    Return a JSON array of 10 items.
    Each item: { "id": string, "category": "Diet"|"Movement"|"Breath"|"Routine", "title": string, "description": string, "benefits": string, "timeOfDay": "Morning"|"Afternoon"|"Evening" }
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              category: { type: Type.STRING },
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              benefits: { type: Type.STRING },
              timeOfDay: { type: Type.STRING }
            }
          }
        }
      }
    });
    return JSON.parse(response.text?.trim() || "[]");
  } catch (error) { return []; }
};

export const getQuickSuggestions = async (userProfile: UserProfile) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-flash-preview";
  const prompt = `Give 5 tiny daily health tasks for ${userProfile.prakriti}. Return as JSON array of {title, description, reason}.`;
  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              reason: { type: Type.STRING }
            }
          }
        }
      }
    });
    return JSON.parse(response.text?.trim() || "[]");
  } catch (error) { return []; }
};
