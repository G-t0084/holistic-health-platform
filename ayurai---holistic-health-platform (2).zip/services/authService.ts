
import { UserProfile, HealthVital, LifestylePlanItem } from "../types";

export interface UserAccount {
  email: string;
  name: string;
  password?: string; // Stored as a simple "hash" string for this demo
  picture?: string;
  profile?: UserProfile;
  vitals: HealthVital[];
  lifestylePlan: LifestylePlanItem[];
}

const STORAGE_KEY = 'ayurai_accounts';
const SESSION_KEY = 'ayurai_active_session';

// Helper to decode JWT without external library
function parseJwt(token: string) {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
    return JSON.parse(jsonPayload);
  } catch (e) {
    return null;
  }
}

// Simple mock "hash" function
const mockHash = (str: string) => `hash_${btoa(str).split('').reverse().join('')}`;

const getAccounts = (): Record<string, UserAccount> => {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : {};
};

const saveAccounts = (accounts: Record<string, UserAccount>) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(accounts));
};

export const authService = {
  // Traditional Email/Password Registration
  register: async (name: string, email: string, password: string): Promise<UserAccount> => {
    // Simulate network delay
    await new Promise(r => setTimeout(r, 800));
    
    const accounts = getAccounts();
    const normalizedEmail = email.toLowerCase().trim();

    if (accounts[normalizedEmail]) {
      throw new Error("An account with this email already exists.");
    }

    const newAccount: UserAccount = {
      email: normalizedEmail,
      name: name.trim(),
      password: mockHash(password),
      vitals: [],
      lifestylePlan: []
    };

    accounts[normalizedEmail] = newAccount;
    saveAccounts(accounts);
    
    localStorage.setItem(SESSION_KEY, normalizedEmail);
    return newAccount;
  },

  // Traditional Email/Password Login
  loginWithPassword: async (email: string, password: string): Promise<UserAccount> => {
    await new Promise(r => setTimeout(r, 600));
    
    const accounts = getAccounts();
    const normalizedEmail = email.toLowerCase().trim();
    const account = accounts[normalizedEmail];

    if (!account || !account.password) {
      throw new Error("Invalid email or password.");
    }

    if (account.password !== mockHash(password)) {
      throw new Error("Invalid email or password.");
    }

    localStorage.setItem(SESSION_KEY, normalizedEmail);
    return account;
  },

  // Google Identity Response
  handleGoogleResponse: async (credential: string): Promise<UserAccount> => {
    const payload = parseJwt(credential);
    if (!payload) throw new Error("Invalid Google token");

    const { email, name, picture } = payload;
    const normalizedEmail = email.toLowerCase().trim();
    const accounts = getAccounts();
    
    if (!accounts[normalizedEmail]) {
      accounts[normalizedEmail] = {
        email: normalizedEmail,
        name: name || 'Google User',
        picture,
        vitals: [],
        lifestylePlan: []
      };
      saveAccounts(accounts);
    } else {
      accounts[normalizedEmail].name = name;
      accounts[normalizedEmail].picture = picture;
      saveAccounts(accounts);
    }
    
    localStorage.setItem(SESSION_KEY, normalizedEmail);
    return accounts[normalizedEmail];
  },

  // OTP Fallback (Maintained)
  sendOTP: async (email: string) => {
    console.log(`[Mock] Sending OTP to ${email}: 123456`);
    return true; 
  },

  loginWithEmail: async (email: string, otp: string): Promise<UserAccount> => {
    if (otp !== '123456') throw new Error('Invalid OTP. Use 123456.');
    
    const normalizedEmail = email.toLowerCase().trim();
    const accounts = getAccounts();
    if (!accounts[normalizedEmail]) {
      accounts[normalizedEmail] = {
        email: normalizedEmail,
        name: normalizedEmail.split('@')[0],
        vitals: [],
        lifestylePlan: []
      };
      saveAccounts(accounts);
    }
    
    localStorage.setItem(SESSION_KEY, normalizedEmail);
    return accounts[normalizedEmail];
  },

  getActiveSession: (): UserAccount | null => {
    const email = localStorage.getItem(SESSION_KEY);
    if (!email) return null;
    return getAccounts()[email] || null;
  },

  syncUserData: (account: UserAccount) => {
    const accounts = getAccounts();
    accounts[account.email.toLowerCase()] = account;
    saveAccounts(accounts);
  },

  logout: () => {
    localStorage.removeItem(SESSION_KEY);
  }
};
